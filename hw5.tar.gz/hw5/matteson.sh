
#!/bin/bash

display_usage(){

	echo "The script must run with two arguments."
	echo "Usage:\n$0 [arguments] \n"
}

if [  $# -le 1 ] 
	then 
		display_usage
		exit 1
fi 


if [ ! -e $1 ]
	then
	echo File $1 does not exist
	exit 1

fi

if [ ! -e $2 ]
	then
	echo File $2 does not exist
	exit 1

fi

filename=$2

awk -f grade.awk report.txt

answer="yes"

while [ "$answer" == "yes" ]
do
	echo "Do you wish to add a student record (yes/no): "
	read answer
	
	if [ "$answer" == "yes" ]; then
			echo "Please enter the name of the student: "
			read name
			

		scoreQ="no"
		scoreH="no"
		scoreM="no"
		scoreF="no"
		scores=0

		echo "scores " $scores

		while [ "$scores" -lt 4 ]
		do
		
				
		echo "Please enter a quiz grade with (Q/q), a hw grade with (H/h), "
		echo "a midterm grade with (M/m) and a final grade with (F/f): "

		read types

		case $types in
			Q|q) echo "Please enter quiz grade: "
			 	 read quizGrade
					if [ $quizGrade -lt 0 ]; then
						echo "Negative Grade not permitted"
						continue
					fi

					if [ $quizGrade -gt 100 ]; then
						echo "Grade greater than 100 not permitted"
						continue
					fi

			 	 let scores++
				 scoreQ="yes"
			 	 
				 
			 	 ;;
			H|h) echo "Please enter homework grade: "
			     	read quizHW
					if [ $quizHW -lt 0 ]; then
						echo "Negative Grade not permitted"
						continue
					fi

					if [ $quizHW -gt 100 ]; then
						echo "Grade greater than 100 not permitted"
						continue
					fi

			     	let scores++
				scoreH="yes"
			     	
			     	;;
			M|m) echo "Please enter midterm grade: "
		         	read quizMidterm
					if [ $quizMidterm -lt 0 ]; then
						echo "Negative Grade not permitted"
						continue
					fi

					if [ $quizMidterm -gt 100 ]; then
						echo "Grade greater than 100 not permitted"
						continue
					fi

		         	let scores++
				scoreM="yes"
		           	
		     	 	;;
			F|f) echo "Please enter Final grade: "
			     	read quizFinalgrade
					if [ $quizFinalgrade -lt 0 ]; then
						echo "Negative Grade not permitted"
						continue
					fi

					if [ $quizFinalgrade -gt 100 ]; then
						echo "Grade greater than 100 not permitted"
						continue
					fi
	 	
			     	let scores++
				scoreF="yes"
			     	
				 ;;
			*) echo "Wrong grade type. Please enter (Q,H,M,F)."
			   ;;
		esac
		
		done
		

	

	
        fi
	
	if [ "$scoreQ" == "yes" ]; then
			
		if [ "$scoreH" == "yes" ]; then
			
			if [ "$scoreM" == "yes" ]; then
				
				if [ "$scoreF" == "yes" ]; then
	
	echo $name $quizGrade $quizHW $quizMidterm $quizFinalgrade >> $filename
	awk -f grade.awk report.txt

	scores="no"

	scoreQ="no"
	scoreH="no"
	scoreM="no"
	scoreF="no"

	fi
		fi
		
			fi

				fi

	
done
