#!/usr/bin/perl -w
# Hw 6 Perl
# Name: Ian Matteson
# Date: 4/5/2016

use strict;

my $finalstate;
my $year60 = 60;
my $yearnum = 0;
my $birthdaymonth = 0;
my @statesort;
my @stateoutput;
my @finalstateout;
my @sorted;
my @txtoutput;
my @doboutput;
my @finaldoboutput;
my @salaryoutput;
my @finalsalaryoutput;
my $salary5;
my $last5;
my $first5;
my $sec;
my $min;
my $hour;
my $mday;
my $mon;
my $year;
my $wday;
my $yday;
my $isdst;

my $local_string;

print "Enter the file name, make sure the filename is in HW6 directory.\n";
my $firstfile =<STDIN>;

open FILE, "$firstfile" or die "cannot open: $!";

my @lines;
my $first = 0;

while (<FILE>){

	chomp(@lines);
	push (@lines, $_);

}

close FILE or die "Cannot close $firstfile: $!";

my $stringline;

print "Employees from IL: \n";
# This for loops finds all the employess from IL
#*********************************************************
for(@lines){

my ($lineon) = $_;

my @fields = split /[:]/, $lineon;
my $name = $fields[0];
my $phone = $fields[1];
my $address = $fields[2];
my $dob = $fields[3];
my $salary = $fields[4];

my @state = split /[ ]/, $address;

my @splitname = split /[ ]/, $name;
my $firstname = $splitname[0];
my $lastname = $splitname[1];

my $realstate = $state[4];
my $realstate2 =  $state[5];

if (length($realstate) == 2){
	
	$finalstate = $realstate;

}

#if (length($realstate2 == 2){

#	$finalstate = $realstate2;
#}


if ($finalstate eq 'IL' ){

	print "$name", " ", "$phone", " ", "$address", " ", "$dob", " ", "$salary";

}

#use for the state.txt

@stateoutput = join(':', "$finalstate", "$lastname", "$firstname\n");

push (@finalstateout, @stateoutput);

#use for the dob.txt

@doboutput = join(':', "$dob\t\t", "$lastname\t\t", "$firstname\n");

push (@finaldoboutput, @doboutput);

@salaryoutput = join(':', "$salary", "$lastname", "$firstname\n");

push (@finalsalaryoutput, @salaryoutput);

}

#*******************************************************************

print "\n\n";
print "Employess with salary above forty thousand dollar: \n";

for(@lines){

my ($lineon2) = $_;

my @fields2 = split /[:]/, $lineon2;
my $name2 = $fields2[0];
my $phone2 = $fields2[1];
my $address2 = $fields2[2];
my $dob2 = $fields2[3];
my $salary2 = $fields2[4];

if ($salary2 > 40000){

		print "$name2", " ", "$phone2", " ", "$address2", " ", "$dob2", " ", "$salary2\n";	
}


}

#******************************************************************
print "\n";
print "Employess born in the sixties: \n";

for(@lines){

my ($lineon3) = $_;

my @fields3 = split /[:]/, $lineon3;
my $name3 = $fields3[0];
my $phone3 = $fields3[1];
my $address3 = $fields3[2];
my $dob3 = $fields3[3];
my $salary3 = $fields3[4];

my @lastname3 = split /[ ]/, $name3;

my $first3 = $lastname3[0];
my $last3 = $lastname3[1];

my @year = split (m@/@, $dob3);

$yearnum = $year[2];

if (($yearnum > 59) and ($yearnum < 70)){

	print "$yearnum", " ", "$last3", " ", "$first3\n";

}



}
#  5 point bonus
#********************************************************************
($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);

$birthdaymonth = $mon + 1;

print "\n";
print "Employees whose birthday is in current month: \n";

for(@lines){

my ($lineon4) = $_;

my @fields4 = split /[:]/, $lineon4;
my $name4 = $fields4[0];
my $phone4 = $fields4[1];
my $address4 = $fields4[2];
my $dob4 = $fields4[3];
my $salary4 = $fields4[4];

my @month2 = split (m@/@, $dob4);

my $bdmonth = $month2[0];

if ($birthdaymonth == $bdmonth){

	print "$name4", " ", "$dob4\n";
}

}

#*******************************************************
# Sort states, last name and name

@finalstateout = sort @finalstateout; 

#foreach my $finalstateout(@finalstateout){

#print "$finalstateout";

#}

#print "@finalstateout";

my $fileout = "state.txt";

unless(open FILE, '>'.$fileout) {die "Unable to create file.\n";}

print FILE "@finalstateout";

close FILE;

@finaldoboutput = sort @finaldoboutput;

#*******************************************************
# sorts dob

#print "@finaldoboutput";

my $fileout2 = "dob.txt";

unless(open FILE, '>'.$fileout2) {die "Unable to create file.\n";}

print FILE "@finaldoboutput";

close FILE;

#******************************************************
# sorts salary

@finalsalaryoutput = sort{$b cmp $a} (@finalsalaryoutput);

my $fileout3 = "salary.txt";

unless(open FILE, '>'.$fileout3) {die "Unable to create file.\n";}

print FILE "@finalsalaryoutput";

close FILE;


